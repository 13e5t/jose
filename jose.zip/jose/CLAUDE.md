# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a client-side JWK (JSON Web Key) cryptographic operations web application for JWT signing, verification, encryption, and decryption. The application runs entirely in the browser using the JOSE library for cryptographic operations.

## Development Setup

This is a static web application that requires no build process or server setup:

1. Open `index.html` directly in a modern web browser
2. The app loads the JOSE library from CDN with multiple fallbacks
3. All cryptographic operations happen client-side

## Architecture

### Core Components

- **`JWKCryptoApp` class (`app.js:1-427`)**: Main application controller that handles all JWK and JWT operations
- **Key Management**: Generates and manages RSA key pairs for signing (RS256) and encryption (RSA-OAEP-256)
- **JWT Operations**: Four main operations via tabbed interface:
  - Sign JWT with RS256
  - Verify JWT signatures
  - Encrypt JWT with RSA-OAEP-256 + A256GCM
  - Decrypt JWE back to original format

### Key Features

- **Dual Key Support**: Separate keys for signing (`use: "sig"`) and encryption (`use: "enc"`)
- **Type Preservation**: Maintains original data type (JSON vs plain text) through encrypt/decrypt cycle using `__originalType` metadata
- **Flexible Input**: Handles both JWK Sets and single JWKs
- **CDN Fallbacks**: Multiple CDN sources (Skypack → jsDelivr → unpkg) for JOSE library loading

### File Structure

- `index.html`: Main UI with tabbed interface for JWK management and JWT operations
- `app.js`: Core application logic and JOSE library integration
- `styles.css`: CSS styling for the interface
- `netlify.toml` / `vercel.json`: Deployment configurations with security headers

## Security Implementation

- Content Security Policy configured in deployment files
- Security headers (X-Frame-Options, X-XSS-Protection, etc.)
- Client-side only operations - private keys never leave browser
- Educational/development use - not production-ready

## Deployment

The application can be deployed to any static hosting service:
- **Netlify**: Direct folder upload (recommended)
- **Vercel**: Using Vercel CLI
- **GitHub Pages**: Upload files to repository

No build process or server-side components required.